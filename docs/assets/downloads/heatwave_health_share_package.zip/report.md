# Impact report: Heatwave and ER visits

- intervention: `2024-07-14 00:00:00`
- outcome: `er_visits`
- controls: `nearby_city_er, temperature_proxy`
- model: `ols`

## Metrics

- avg_effect: 7.1339
- cum_effect: 328.1605

## Scenario

Heatwave and ER visits
