# Impact report: Detector downtime after a solar storm

- intervention: `2024-05-18 00:00:00`
- outcome: `uptime_pct`
- controls: `reference_detector_uptime, solar_flux_proxy`
- model: `ols`

## Metrics

- avg_effect: -3.3266
- cum_effect: -126.4120

## Scenario

Detector downtime after a solar storm
