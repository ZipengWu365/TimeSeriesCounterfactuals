# Impact report: Repo breakout after a launch

- intervention: `2025-12-18 00:00:00`
- outcome: `repo_stars_new`
- controls: `peer_repo_a, peer_repo_b`
- model: `ols`

## Metrics

- avg_effect: 22.0344
- cum_effect: 705.0998

## Scenario

Repo breakout after a launch
