# Impact report: Hospital surge during a respiratory outbreak

- intervention: `2024-01-17 00:00:00`
- outcome: `icu_occupancy`
- controls: `nearby_icu, respiratory_index`
- model: `ols`

## Metrics

- avg_effect: 12.4970
- cum_effect: 412.4008

## Scenario

Hospital surge during a respiratory outbreak
