# Impact report: Viral attention spike

- intervention: `2025-10-14 00:00:00`
- outcome: `attention_index`
- controls: `peer_topic_a, peer_topic_b`
- model: `ols`

## Metrics

- avg_effect: 12.5834
- cum_effect: 654.3358

## Scenario

Viral attention spike
